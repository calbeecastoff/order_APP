// components/submit-bar/submit-bar.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    isShowSubmit:{
      type:Boolean,
      value:false,
      observer:'updateSubmit',

    },
    totalPrice:{
      type:Number,
      value:0
    },
    cart:{
      type:Array,
      value:[]
    },
    cartCount:{
      type:String,
      value:''
    }
  },
  /**
   * 组件的初始数据
   */
  data: {

    isZero:true
  },

  /**
   * 组件的方法列表
   */
  methods: {
    updateSubmit(){
      this.triggerEvent('updatePadding',this.data.isShowSubmit)
    },
    openOrder(e){
      this.triggerEvent('openOrder')
    },
    //在购物车中修改商品的值

  }
})
