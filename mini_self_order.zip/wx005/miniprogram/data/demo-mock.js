const Mock = require('mockjs')

var Random = Mock.Random
Random.title(3, 4)
Random.increment(-1)
var arr=new Array()
for (let index = 0; index < 5; index++) {
  //先随机一个菜系的集合
  var childrenData =Mock.mock({
    "children|1-10": [
      {
        "name|+1": [
          "Hello",
          "Mock.js",
          "!"
        ],
        "price|+1": [
          5,
          15,
          18,
          20,
          25
        ],
        "desc|+1": [
          "Hello",
          "Mock.js",
          "!"
        ],"image|+1": [
          Random.image('200x100', '#4A7BF7', 'Hello'),
          Random.image('200x100', '#4A7BF7', 'Hello'),
  
        ]
      }
    ]
  })
  //将随机的菜系集合起来0-4
  var menuData = {
    typeIdx:Mock.mock('@increment'),
    title:Mock.mock('@title'),
    children :childrenData.children
  }
  arr[index]=menuData
}
console.log(arr[0].children)
//将数组转成json写入文件
