const mock = require('./mock')
Page({
  /**
   * 页面的初始数据
   */
  data: {
    images: [
      '../../images/swiper01.jpg',
      '../../images/swiper02.jpg',
      '../../images/swiper03.jpg',
      '../../images/swiper04.jpg',
    ],
    menu: [],
    isShowSubmit:false,
    isShowContent:false,
    activeKey:0,
    scrollRight:0,
    end:'',
    cartCount:''
  },
  lens:[],
  MenuQueue:[],
  ScrollQueue:[],
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //是否第一次登陆
    // new Promise((resolve, reject) => {
      let menu = wx.getStorageSync('menu')||mock.menu

        let cartCount = wx.getStorageSync('cartCount')||''
        this.setData({
          menu:menu,
          cartCount:cartCount
        })
        let cart = wx.getStorageSync('cart')||[]
        wx.setStorageSync('menu', menu)
        this.loadCart(menu,cart)
        this.loadTotal(cart)
        this.loadLens(menu)
        this.createMenuQueue(menu)
        this.createScrollQueue()
    //   })
    // })
    // let cart = wx.getStorageSync('cart')||[]
    //判断是否有购物车缓存
  },
  onUnload:function(){

  },
  onHide:function(){
    console.log('onhiden');
  },

  addToCart(e) {
    if(!this.isShowSubmit){
      this.setData({
        isShowSubmit:true
      })
    }
    const {num,price,id,option,food_title,thumb,tag,desc} = e.detail
    let menu = wx.getStorageSync('menu')||[]
    let cart = wx.getStorageSync('cart')||[]
    let totalPrice = wx.getStorageSync('totalPrice')||0
    totalPrice+=price*option*100
    //判断food是否在购车中
    let findFood = cart.findIndex(x=>{
      return id==x.id
    })
    //如果有
    if(findFood!==-1){
      cart[findFood].num=num 
    }else{
      let newOne = {num,price,id,food_title,thumb,tag,desc}
      cart.push(newOne)
    }
    if(num==0){
      //应该将它从购物中移除
      cart.splice(findFood,1)
      //隐藏
      if(cart.length==0){
        this.setData({
          isShowSubmit:false,
          isShowContent:false
        })
      }
    }
    this.updateMenu(menu,id,num)
    //判断food-id是在哪个区间，
    const menuID = this.findMenuID(id)
    menu[menuID].badge=menu[menuID].badge||0
    menu[menuID].badge+=option
    if(menu[menuID].badge==0){
      menu[menuID].badge=''
    }
    let cartCount = this.data.cartCount===''? '0' : this.data.cartCount 
    cartCount=parseInt(cartCount+=option)
    this.setData({
      cartCount:cartCount,
      menu:menu,
      cart:cart,
      totalPrice:totalPrice
    },()=>{
      wx.setStorageSync('cart', cart)
      wx.setStorageSync('totalPrice', totalPrice)
      wx.setStorageSync('menu', menu)
      wx.setStorageSync('cartCount', cartCount)
    })
  },
  loadCart(menu, cart) {
    if (cart.length > 0) {
      //修改menu
      menu.forEach(menuItem => {
        menuItem.children.forEach(food => {
          cart.forEach(cartItem => {
            if (cartItem.id == food.food_id) {
              food.num = cartItem.num
            }
          })
        })
      })
    }
    this.setData({
      cart: cart
    })
  },
  loadTotal(cart) {
    if (cart.length > 0) {
      //重新计算totoal
      let total = 0
      cart.forEach(el => {
        total += el.price * el.num * 100
      })
      this.setData({
        totalPrice: total,
        isShowSubmit: true
      })
      wx.setStorageSync('totalPrice', total)
    } else {
      return
    }
  },
  loadLens(menu){
    const height=126
    const lens=[]
    menu.forEach(el=>{
      let len = el.children.length*height
      lens.push(len)
    })
    this.lens=lens
  },
  updatePadding(e) {
    const detail = e.detail
    if (detail) {
      this.setData({
        end: 'display:block'
      })
    } else {
      this.setData({
        end: 'display:none'
      })
    }
  },
  updateMenu(menu,food_id,food_num) {
    menu.forEach(menuItem => {
      menuItem.children.forEach(food => {
          if (food_id == food.food_id) {
            food.num = food_num
        }
      })
    })
  },
  onCloseOrder(){
    this.setData({
      isShowContent:false
    })
  },
  openOrder() {
    console.log('openOrder');
    this.setData({
      isShowContent: true
    })
  },
  scrollMenu(e){
    //
    const ScrollQueue = this.ScrollQueue
    let scrollTop =e.detail.scrollTop
    if(scrollTop <= ScrollQueue[1]){
      scrollTop=ScrollQueue[0]
    }else if(scrollTop <= ScrollQueue[2]){
      scrollTop=ScrollQueue[1]
    }else if(scrollTop <= ScrollQueue[3]){
      scrollTop=ScrollQueue[2]
    }else if(scrollTop <= ScrollQueue[4]){
      scrollTop=ScrollQueue[3]
    } else if(scrollTop > ScrollQueue[4]){
      scrollTop=ScrollQueue[4]
    }
    switch (scrollTop) {
      case ScrollQueue[0]:
        this.setData({
          activeKey:0
        })
        break;
      case ScrollQueue[1]:
        this.setData({
          activeKey:1
        })
        break;
      case ScrollQueue[2]:
        this.setData({
          activeKey:2
        })
        break;
      case ScrollQueue[3]:
        this.setData({
          activeKey:3
        })
        break;
      case ScrollQueue[4]:
        this.setData({
          activeKey:4
        })
        break;
    }
    
  },
  doscroll(e){
    const {index }=e.detail
    const ScrollQueue=this.ScrollQueue
    this.setData({
      scrollRight:ScrollQueue[index]+1
    })
    
  },
  createMenuQueue(menu){
    const MenuQueue=[]
    menu.forEach(m=>{
      let len = m.children.length
      MenuQueue.push(len)
    })
    this.MenuQueue=MenuQueue
  },
  findMenuID(food_id){
    const MenuQueue=this.MenuQueue
    let menu_id=0
    let counter = 0
    MenuQueue.forEach(m=>{
      counter+=m
      if(counter<=food_id){
        menu_id++
      }
    })
    return menu_id
  },
  createScrollQueue(){
    const ScrollQueue=[]
    const lens = this.lens
    let total = 0
    ScrollQueue.push(0)
    for(let i = 0 ; i <4;i++){
      total+=lens[i]
      ScrollQueue.push(total)
    }
    this.ScrollQueue=ScrollQueue
  },
  cleanCart(){
    const menu=wx.getStorageSync('menu')
    const init_totalPrice=0

    menu.forEach(item=>{
      if(item.badge){
        item.badge=''
      }
      item.children.forEach(c=>{
        c.num = 0
      })
    })
    console.log(menu);
    this.setData({
      menu:menu,
      isShowSubmit:false,
      totalPrice:init_totalPrice,
      cartCount:0,
      isShowContent:false,
      cart:[]
    },()=>{
      wx.setStorageSync('menu', menu)
      wx.setStorageSync('totalPrice', init_totalPrice)
      wx.setStorageSync('cart',[])

    })
    
  }
})
