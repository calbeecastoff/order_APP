// components/card/card.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    menu:{
      type:Array,
      value:[],
    },
    num:{
      type:Number,
      value:0,
    },
    price:{
      type:Number,
      value:0
    },
    food_id:{
      type:Number,
      value:0
    },
    desc:{
      type:String,
      value:'desc'
    },
    food_title:{
      type:String,
      value:'food_title'
    },
    thumb:{
      type:String,
      value:'thumb'
    },
    tag:{
      type:String,
      value:'tag'
    },
    
  },

  /**
   * 组件的初始数据
   */
  data: {
  },
  /**
   * 组件的方法列表
   */
  methods: {
    cardHandle(e){
      let {id,option,price,food_title,thumb,tag,desc} = e.target.dataset
      option = option=="1"? 1:-1
      let num = this.data.num
      if(num==0&&option==-1){
        return
      }
      this.setData({
        num:num+=option
      })
      this.triggerEvent('addToCart',{num,id,price,option,food_title,thumb,tag,desc})
    },
  },
})
